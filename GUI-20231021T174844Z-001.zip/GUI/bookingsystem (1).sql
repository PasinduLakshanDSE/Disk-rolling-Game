-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 16, 2023 at 07:54 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `bookingsystem`
--

-- --------------------------------------------------------

--
-- Table structure for table `booking_nfo`
--

CREATE TABLE `booking_nfo` (
  `Name` varchar(50) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `Film_Name` varchar(20) DEFAULT NULL,
  `Time` varchar(10) DEFAULT NULL,
  `Total_Price` decimal(20,2) DEFAULT NULL,
  `date` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `booking_nfo`
--

INSERT INTO `booking_nfo` (`Name`, `phone`, `Film_Name`, `Time`, `Total_Price`, `date`) VALUES
('Pasindu', '0783106081', 'Kadira Divyaraja', '10.00 AM', 1050.00, '2023-10-19'),
('Saduni', '0772768404', 'Kadira Divyaraja', '12.00 PM', 1750.00, '2023-10-20');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
